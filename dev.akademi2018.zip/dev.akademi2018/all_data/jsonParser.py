import csv
import json

with open('all_data 3.json') as f:
    data = json.load(f)
    f = csv.writer(open("test.csv", "w"))

for x in data:
    f.writerow(x.values())
