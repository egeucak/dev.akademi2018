import React from 'react';
import {
  ScrollView,
  TouchableOpacity
  // View,
  // Text
} from 'react-native';

import axios from 'axios';

import { Icon } from 'expo';

import { Constants, Colors, View, Card, Button, Text } from 'react-native-ui-lib';

import {
  getAds
} from '../services/Service';

export default class SettingsScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      ads: null,
    }
    // this.state = {
    //   ads: [
    //     {
    //       "id": 1,
    //       "title": "ANKALİFE PRESTİJ KONUTLARI",
    //       "description": "5 +1 VE 4+1 OTURUMA HAZIR LÜKS DAİRELER",
    //       "callToAction": "GÜVEN ve SEVGİYLE",
    //       "bidPriceKurus": 140,
    //       "dailyBudgetKurus": 2000,
    //       "remainingBudgetKurus": 1400
    //     },
    //     {
    //       "id": 2,
    //       "title": "Reklamin Başliği",
    //       "description": "Reklamin Açıklamasi",
    //       "callToAction": "Reklamin Call to Actioni",
    //       "bidPriceKurus": 200,
    //       "dailyBudgetKurus": 2000,
    //       "remainingBudgetKurus": 900
    //     }
    //   ]
    // }
  }

  componentDidMount() {
    getAds().then(ads => {
      // console.log(ads);
      this.setState({ads : ads});
    })
  }

  renderAd = (data) => {
    console.log("Img => ", data.imgUrl);
    return (
      <View key={data.id} >
        <Card row height={120} style={{ marginBottom: 15 }} onPress={() => { }} enableBlur>
          <Card.Section body>
            <Card.Section>
              <Text text70 dark10>
                {data.title}
              </Text>
              <Card.Item>
                <TouchableOpacity style={{
                  borderWidth: 1,
                  borderColor: 'rgba(0,0,0,0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: 30,
                  height: 30,
                  backgroundColor: '#fff',
                  borderRadius: 30,
                  marginRight: 10
                }}>
                  <View>
                    <Icon.Entypo name='area-graph' size={20} color='blue' />
                  </View>
                </TouchableOpacity>
                <TouchableOpacity style={{
                  borderWidth: 1,
                  borderColor: 'rgba(0,0,0,0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: 30,
                  height: 30,
                  backgroundColor: '#fff',
                  borderRadius: 30,
                }}>
                <View>
                  <Icon.MaterialCommunityIcons name='play-pause' size={20} color='green' />
                </View>
              </TouchableOpacity>
              </Card.Item>
            </Card.Section>
            <Card.Section>
              <Text text90 dark10>
                {data.description}
              </Text>
            </Card.Section>
            <Card.Section footer>
              <Text text90 color={Colors.dark50}>
                Bid price {data.bidPriceKurus}
              </Text>
              <Text text90 color={Colors.dark50}>
                Budget {data.dailyBudgetKurus}
              </Text>
              <Text text90 color={Colors.dark50}>
                Remaining Budget {data.remainingBudgetKurus ? data.remainingBudgetKurus : data.dailyBudgetKurus}
              </Text>
              <Card.Item>
              </Card.Item>
            </Card.Section>
          </Card.Section>
          <Card.Image height={'100%'} imageSource={{uri: data.imgUrl}} />
        </Card>
        <View>

        </View>

      </View>
    );
  }

  static navigationOptions = {
    title: 'Your Ads',
  };

  render() {
    /* Go ahead and delete ExpoConfigView and replace it with your
     * content, we just wanted to give you a quick view of your config */
    if (this.state.ads) {
      return (
      <ScrollView>
        {this.state.ads.map(ad => this.renderAd(ad))}
      </ScrollView>
    );
  } else {
    return <Text>Loading</Text>
  }
  }
}
