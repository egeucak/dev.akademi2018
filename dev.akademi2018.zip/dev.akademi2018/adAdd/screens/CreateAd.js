import React from "react";
import { ScrollView, StyleSheet, TouchableOpacity } from "react-native";

import { DocumentPicker } from "expo";

import {
  Constants,
  Colors,
  View,
  Card,
  Button,
  Text,
  TextInput
} from "react-native-ui-lib";

import {
  createAd,
  fileToBase64
} from '../services/Service';

const INPUT_SPACING = 10;

const REQUIRED_LIST = [
  "base64File",
  "adTitle",
  "adDescription",
  "dailyBudget",
  "bidPrice"
]

export default class LinksScreen extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      imageName: null,
      imageUri: null,
      base64File: null,
      adTitle: "",
      adDescription: "",
      dailyBudget: 0,
      bidPrice: 0,
    };
  }
  static navigationOptions = {
    title: "Create an Ad"
  };

  handleChange = (txt, type) => {
    this.setState({ [type]: txt });
  };

  pickImage = () => {
    DocumentPicker.getDocumentAsync({
      type: "image/*"
    })
      .then(res => {
        if (res.type === "cancel") {
          return 0;
        }
        
        fileToBase64(res.uri).then(base64File => {
          this.setState({
            base64File,
            imageName: res.name,
            imageUri: res.uri
          });
        });
      })
      .catch(err => {
        console.log(err);
      });
  };

  createAd = () => {
    for (let i = 0; i < REQUIRED_LIST.length; i++ ) {
      const elm = REQUIRED_LIST[i];
      if (!this.state[elm]) {
        alert("You need to fill every field");
        return 0;
      }
    }
    const {
      adTitle,
      adDescription,
      dailyBudget,
      bidPrice,
      base64File
    } = this.state;

    createAd({
      title: adTitle,
      description: adDescription,
      dailyBudgetKurus: dailyBudget,
      bidPriceKurus: bidPrice,
      base64File
    }).then(() => {
      alert("Your ad is created");
    }).catch(er => {
      alert(er);
    });
  }

  renderAdView = () => {
    console.log("DANG");
    return (
      <View style={styles.fields}>
        <TextInput
          text60
          containerStyle={{ marginBottom: INPUT_SPACING }}
          floatingPlaceholder
          placeholder="Enter ad title"
          onChangeText={txt => this.handleChange(txt, "adTitle")}
          floatOnFocus
        />
        <TextInput
          text60
          containerStyle={{ marginBottom: INPUT_SPACING }}
          floatingPlaceholder
          placeholder="Enter ad description"
          onChangeText={txt => this.handleChange(txt, "adDescription")}
          floatOnFocus
        />
        <View
          style={{
            // flex: 1,
            flexDirection: "row",
            justifyContent: "space-between"
          }}
        >
          <TextInput
            style={{
              width: "45%"
            }}
            text70
            containerStyle={{ marginBottom: INPUT_SPACING }}
            floatingPlaceholder
            placeholder="Enter your daily budget"
            onChangeText={txt => this.handleChange(txt, "dailyBudget")}
            floatOnFocus
          />
          <TextInput
            style={{
              width: "45%"
            }}
            text70
            containerStyle={{ marginBottom: INPUT_SPACING }}
            floatingPlaceholder
            placeholder="Enter your bid price"
            onChangeText={txt => this.handleChange(txt, "bidPrice")}
            floatOnFocus
          />
        </View>
        <View>
          <Button size="small" onPress={() => this.pickImage()}
            style={{
              width: '50%',
              alignSelf: 'center'
            }}
          >
            <View>
              <Text>Pick an image</Text>
            </View>
          </Button>
          {this.state.imageName && <Text>{this.state.imageName}</Text>}
          <Button size="large" onPress={() => this.createAd()} backgroundColor='green'
            style={{
              width: '80%',
              alignSelf: 'center',
              margin: 30
            }}
          >
            <View>
              <Text style={{ color: 'white' }}>Create Ad</Text>
            </View>
          </Button>
        </View>
      </View>
    );
  };

  render() {
    return <View>{this.renderAdView()}</View>;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    backgroundColor: "#fff"
  },
  fields: {
    margin: 10
  }
});
