/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */


const Storage = require("@google-cloud/storage");
const datastore = require("@google-cloud/datastore")();

const path = require("path");
const os = require("os");
const fs = require("fs");
const _ = require("lodash");

const makeid = () => {
  let text = "";
  const from = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (let i = 0; i < 8; i++) {
    text += from.charAt(Math.floor(Math.random() * from.length));
  }

  return text;
};

const decodeBase64Image = dataString => {
  console.log("Data=> ", dataString);
  const matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
  const response = {};

  if (matches.length !== 3) {
    return new Error("Invalid input string");
  }

  response.type = matches[1];
  response.data = new Buffer(matches[2], "base64");

  return response;
};

const saveBase64ToCloudStorage = (base64Data) => {
  const storage = new Storage();
  const bucketName = "ad_images_dev_akademi";
  return new Promise((resolve, reject) => {
    if (!base64Data) resolve("");
    const imageTypeRegularExpression = /\/(.*?)$/;
	
  	console.log("Data=> ", base64Data);
    // const imageBuffer = decodeBase64Image(base64Data);
    const imageBuffer = base64Data;
    const crypto = require("crypto");
    const seed = crypto.randomBytes(20);
    const uniqueSHA1String = crypto
      .createHash("sha1")
      .update(seed)
      .digest("hex");

    const fileName = "image-" + uniqueSHA1String;
    //const imageType = imageBuffer.type.match(imageTypeRegularExpression);
    const imageType = "blob";

    const tmpdir = os.tmpdir();
    const filepath = tmpdir + "/" + fileName + "." + imageType;

    fs.writeFile(filepath, imageBuffer, evt => {
      console.log("Saved file to disk at location ", filepath);
      storage
        .bucket(bucketName)
        .upload(filepath, {
          gzip: true
        })
        .then(evt => {
          const fileName = filepath.replace("/tmp/", "");
          console.log(`${fileName} uploaded to ${bucketName} with ${evt}`);
          fs.unlinkSync(filepath);
          const imgUrl = `https://storage.googleapis.com/${bucketName}/${fileName}`;
          resolve(imgUrl);
        })
        .catch(err => {
          reject(err);
        });
    });
  });
}

const saveDataToDatastore = (fields) => {
  return new Promise((resolve, reject) => {
    const kind = "ad";
    const customId = makeid();
    const announcementKey = datastore.key([kind, customId]);
    fields["date"] = new Date();
    fields["adId"] = customId;

    console.log("It should be saving to datastore now");
    const announcement = {
      key: announcementKey,
      data: fields
    };
    console.log("announcement=> ", announcement);
    datastore
      .save(announcement)
      .then(() => {
        console.log("Saved anouncement");
        resolve(fields);
      })
      .catch(err => {
        console.error("ERROR SAVING TO DATASTORE: ", err);
        reject(err);
      });
  });
}

const handlePost = (req, res) => {
  	const incomingPostData = req.body;
  	saveBase64ToCloudStorage(incomingPostData.base64File).then(imgUrl => {
    incomingPostData.imgUrl = imgUrl;
    delete incomingPostData.base64File;

    saveDataToDatastore(incomingPostData)
      .then(saveResult => {
        res.status(200).json(saveResult);
      })
      .catch(err => {
        res.status(400).json(err);
      });
  });
}

const handleGet = (req, res) => {
  const entityKind = "ad";
	const userId = req.query.uid;
  console.log(userId);
  	const query = datastore.createQuery(entityKind).filter("UID", "=", userId);
    datastore
      .runQuery(query)
      .then(results => {
        let result = results[0];
      console.log(result);
        res.json(result);
      })
      .catch(err => {
        res.status(400).json(err);
      });
}

exports.helloWorld = (req, res) => {  
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "*");
  if (req.method === 'POST') {
  	handlePost(req, res);
  } else if (req.method === 'GET'){
  	handleGet(req, res);           
  }else {
  	res.status(405);
  }
};
