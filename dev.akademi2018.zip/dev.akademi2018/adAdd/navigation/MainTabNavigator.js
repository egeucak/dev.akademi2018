import React from 'react';
import { Platform } from 'react-native';
import { createStackNavigator, createBottomTabNavigator } from 'react-navigation';

import TabBarIcon from '../components/TabBarIcon';
import HomeScreen from '../screens/HomeScreen';
import CreateAd from '../screens/CreateAd';
import ViewAds from '../screens/ViewAds';

const HomeStack = createStackNavigator({
  Home: HomeScreen,
});

HomeStack.navigationOptions = {
  tabBarLabel: 'Home',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={"remove-red-eye"}
    />
  ),
};

const CreateAdStack = createStackNavigator({
  Links: CreateAd,
});

CreateAdStack.navigationOptions = {
  tabBarLabel: 'Create Ad',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={"edit"}
    />
  ),
};

const ViewAdStack = createStackNavigator({
  ViewAds: ViewAds,
});

ViewAdStack.navigationOptions = {
  tabBarLabel: 'View Ad',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={"check"}
    />
  ),
};

export default createBottomTabNavigator({
  HomeStack,
  CreateAdStack,
  ViewAdStack,
});
