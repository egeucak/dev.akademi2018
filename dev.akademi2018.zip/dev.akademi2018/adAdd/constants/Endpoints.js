export const GetEstimationEndpoint = "https://us-central1-dev-akademi2018.cloudfunctions.net/GetEstimation";
export const adEndpoint = "https://us-central1-dev-akademi2018.cloudfunctions.net/Ads";
