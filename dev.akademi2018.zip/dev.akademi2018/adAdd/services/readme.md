The project is built with react native

First thing that i had in mind was building a price estimator, and using that estimator in a mobile app to suggest bid price

But I realized that is is taking longer than I anticipated, and decided to just build the mobile app for posting ads.

But it does not also work as I expected, I wanted it to show images as well. But time ran out.

For runnig project type 

npm start
