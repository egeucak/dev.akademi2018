import axios from 'axios'
import base64 from 'base64-js'
import {
    FileSystem,
    Constants
} from 'expo'

import {
    adEndpoint
} from '../constants/Endpoints';

export const getEstimation = (data) => {
    axios.post(
        Endpoint.getEstimation,
        data
        ).then(res => {

        })
        .catch(err => {

        })
}

stringToUint8Array = (str) => {
    const length = str.length
    const array = new Uint8Array(new ArrayBuffer(length))
    for(let i = 0; i < length; i++) array[i] = str.charCodeAt(i)
    return array
}

export const fileToBase64 = (uri) => {
    console.log(uri);
    return new Promise( (resolve, reject) => {
        try {
            FileSystem.readAsStringAsync(uri).then(content => {
                console.log(base64.fromByteArray(stringToUint8Array(content)))
                resolve(base64.fromByteArray(stringToUint8Array(content)));
            });
        } catch(e) {
            console.warn('fileToBase64()', e.message)
            reject(e);
        }
    });
}

export const createAd = (data) => {
    data["UID"] = Constants.deviceId;
    return new Promise((resolve, reject) => {
        axios.post(
            adEndpoint,
            data
        ).then(res => {
            resolve(res);
        }).catch(err => {
            console.log(err);
            reject(err);
        })
    });
}

export const getAds = () => {
    return new Promise((resolve, reject) => {
        axios.get(
            adEndpoint + "?uid=" + Constants.deviceId
        ).then(async res => {
            const images = await res.data.map((async (data) => {
                const imageBase64 = await axios.get(data.imgUrl)
                image = imageBase64.data.replace('/f39', 'data:image/png;base64,');
                return image;
            }))
            console.log(Promise.all(images));
            resolve(res.data);
        }).catch(err => {
            console.log(err);
            reject(err);
        });
    });
}
